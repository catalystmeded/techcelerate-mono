<?php


namespace Uncanny_Automator_Pro;


/**
 * Class Automator_Pro_Helpers_Recipe
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Helpers_Recipe extends \Uncanny_Automator\Automator_Helpers_Recipe {

	/**
	 * @var \Uncanny_Automator_Pro\Zapier_Pro_Helpers
	 */
	public $zapier;
	/**
	 * @var \Uncanny_Automator_Pro\Gotowebinar_Pro_Helpers
	 */
	public $gotowebinar;
	/**
	 * @var \Uncanny_Automator_Pro\Gototraining_Pro_Helpers
	 */
	public $gototraining;
	/**
	 * @var \Uncanny_Automator_Pro\Twilio_Pro_Helpers
	 */
	public $twilio;
	/**
	 * @var \Uncanny_Automator_Pro\Zoom_Pro_Helpers
	 */
	public $zoom;
	/**
	 * @var \Uncanny_Automator_Pro\Zoom_Webinar_Pro_Helpers
	 */
	public $zoom_webinar;

	/**
	 *
	 */
	public static function load_pro_recipe_helpers() {
		global $uncanny_automator;
		$helpers = Utilities::get_all_helper_instances();

		if ( $helpers ) {
			foreach ( $helpers as $integration => $class ) {
				if ( isset( $uncanny_automator->helpers->recipe->$integration ) ) {
					if ( property_exists( $uncanny_automator->helpers->recipe->$integration, 'pro' ) ) {
						$uncanny_automator->helpers->recipe->$integration->setPro( $class );
					}
				} else {
					$uncanny_automator->helpers->recipe->$integration = $class;
					$uncanny_automator->helpers->recipe->$integration->setOptions( $class );
					$uncanny_automator->helpers->recipe->$integration->setPro( $class );
				}
			}
		}
	}
}