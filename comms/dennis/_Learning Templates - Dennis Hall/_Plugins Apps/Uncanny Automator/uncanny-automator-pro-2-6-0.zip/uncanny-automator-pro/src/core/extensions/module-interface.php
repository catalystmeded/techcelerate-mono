<?php

namespace Uncanny_Automator_Pro;

/**
 * Interface Module_interface
 * @package Private_Plugin_Boilerplate
 */
interface Module_interface {

	/**
	 * @public
	 * @return mixed
	 */
	public function get_details();


}