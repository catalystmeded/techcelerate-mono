<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Mycred_Helpers;

/**
 * Class Mycred_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Mycred_Pro_Helpers extends Mycred_Helpers {

	/**
	 * Mycred_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Mycred_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}

	}

	/**
	 * @param Mycred_Pro_Helpers $pro
	 */
	public function setPro( Mycred_Pro_Helpers $pro ) {
		$this->pro = $pro;
	}
}