<?php

namespace Uncanny_Automator_Pro;

/**
 * Class ANON_GF_SUBFIELD
 * @package Uncanny_Automator_Pro
 */
class ANON_GF_SUBFORM {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'GF';

	private $trigger_code;
	private $trigger_meta;

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {
		$this->trigger_code = 'ANONGFSUBFORM';
		$this->trigger_meta = 'ANONGFFORMS';
		$this->define_trigger();
	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function define_trigger() {

		global $uncanny_automator;

		$trigger = array(
			'author'              => $uncanny_automator->get_author_name( $this->trigger_code ),
			'support_link'        => $uncanny_automator->get_author_support_link( $this->trigger_code ),
			'integration'         => self::$integration,
			'code'                => $this->trigger_code,
			/* translators: Anonymous trigger - Gravity Forms */
			'sentence'            => sprintf( __( '{{A form:%1$s}} is submitted', 'uncanny-automator-pro' ), $this->trigger_meta ),
			/* translators: Anonymous trigger - Gravity Forms */
			'select_option_name'  => __( '{{A form}} is submitted', 'uncanny-automator-pro' ),
			'action'              => 'gform_after_submission',
			'type'                => 'anonymous',
			'priority'            => 20,
			'accepted_args'       => 2,
			'validation_function' => array( $this, 'gform_submit' ),
			'options'             => [
				$uncanny_automator->helpers->recipe->gravity_forms->options->list_gravity_forms( null, $this->trigger_meta ),
			],
		);

		$uncanny_automator->register->trigger( $trigger );

		return;
	}

	/**
	 * Validation function when the trigger action is hit
	 *
	 * @param $entry
	 * @param $form
	 */
	public function gform_submit( $entry, $form ) {

		global $uncanny_automator;

		if ( empty( $entry ) ) {
			return;
		}

		$user_id = get_current_user_id();

		$args = [
			'code'    => $this->trigger_code,
			'meta'    => $this->trigger_meta,
			'post_id' => $form['id'],
			'user_id' => $user_id,
		];
		if ( isset( $uncanny_automator->process ) && isset( $uncanny_automator->process->anon ) && $uncanny_automator->process->anon instanceof Automator_Pro_Recipe_Process_Anon ) {
			$uncanny_automator->process->anon->maybe_add_anon_trigger_entry( $args );
		} else {
			$uncanny_automator->maybe_add_trigger_entry( $args );
		}
	}
}