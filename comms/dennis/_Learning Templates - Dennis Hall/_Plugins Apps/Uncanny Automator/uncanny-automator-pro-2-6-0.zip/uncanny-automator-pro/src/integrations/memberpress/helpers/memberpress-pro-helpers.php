<?php


namespace Uncanny_Automator_Pro;


use Uncanny_Automator\Memberpress_Helpers;

/**
 * Class Memberpress_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Memberpress_Pro_Helpers extends Memberpress_Helpers {
	/**
	 * Memberpress_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Memberpress_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}

	}

	/**
	 * @param Memberpress_Pro_Helpers $pro
	 */
	public function setPro( Memberpress_Pro_Helpers $pro ) {
		parent::setPro( $pro );
	}
}