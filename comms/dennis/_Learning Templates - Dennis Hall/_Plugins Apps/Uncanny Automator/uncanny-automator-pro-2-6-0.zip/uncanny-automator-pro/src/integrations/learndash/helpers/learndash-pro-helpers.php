<?php

namespace Uncanny_Automator_Pro;

use Uncanny_Automator\Learndash_Helpers;

/**
 * Class Learndash_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Learndash_Pro_Helpers extends Learndash_Helpers {
	/**
	 * Learndash_Pro_Helpers constructor.
	 */
	public function __construct() {

		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Learndash_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}


		add_action( 'wp_ajax_select_lesson_from_course_MARKLESSONNOTCOMPLETE', array(
			$this,
			'select_lesson_from_course_no_any',
		) );
		add_action( 'wp_ajax_select_lesson_from_course_MARKTOPICNOTCOMPLETE', [
			$this,
			'lesson_from_course_func_no_any'
		], 15 );
		add_action( 'wp_ajax_select_topic_from_lesson_MARKTOPICNOTCOMPLETE', [
			$this,
			'topic_from_lesson_func_no_any'
		], 15 );

		add_action( 'wp_ajax_select_lesson_from_course_LD_SUBMITASSIGNMENT', array(
			$this,
			'lesson_from_course_func'
		), 15 );
	}

	/**
	 * @param Learndash_Pro_Helpers $pro
	 */
	public function setPro( Learndash_Pro_Helpers $pro ) {
		parent::setPro( $pro );
	}
}