<?php

namespace Uncanny_Automator_Pro;


use Uncanny_Automator\Fr_Tokens;

/**
 * Class Fr_Anon_Tokens
 * @package Uncanny_Automator_Pro
 */
class Fr_Anon_Tokens extends Fr_Tokens {

	/**
	 * Integration code
	 *
	 * @var string
	 */
	public static $integration = 'FR';

	/**
	 * Fr_Anon_Tokens constructor.
	 */
	public function __construct() {
		//*************************************************************//
		// See this filter generator AT automator-get-data.php
		// in function recipe_trigger_tokens()
		//*************************************************************//
	}
}