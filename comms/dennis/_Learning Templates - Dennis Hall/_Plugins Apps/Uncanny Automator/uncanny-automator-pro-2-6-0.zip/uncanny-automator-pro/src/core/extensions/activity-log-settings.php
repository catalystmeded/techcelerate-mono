<?php

namespace Uncanny_Automator_Pro;

if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Class Activity_Log_Settings
 *
 * @package Uncanny_Automator_Pro
 */
class Activity_Log_Settings {

	/**
	 * Activity Page Title
	 *
	 * @var string $settings_page_slug setting page slug.
	 */
	public $settings_page_slug;

	/**
	 * Class constructor
	 */
	public function __construct() {
		add_filter( 'uap_settings_tabs', [ $this, 'add_purge_settings' ] );
		add_action( 'uapro_auto_purge_logs', array( $this, 'delete_old_logs' ) );
	}

	/**
	 *
	 * Add values to settings tab
	 *
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function add_purge_settings( $tabs ) {
		$tabs['settings'] = [
			'name'           => __( 'Settings', 'uncanny-automator-pro' ),
			'title'          => __( 'Auto-prune activity logs', 'uncanny-automator-pro' ),
			'description'    => __( 'Enter a number of days below to have trigger and action log entries older than the specified number of days automatically deleted from your site daily. Trigger and action log entries will only be deleted for recipes with "Completed" status.', 'uncanny-automator-pro' ),
			'is_pro'         => true,
			'settings_field' => 'uap_automator_settings',
			//settings_fields( 'uap_automator_settings' )
			'wp_nonce_field' => 'uap_automator_nonce',
			//wp_nonce_field( 'uap_automator_nonce', 'uap_automator_nonce' )
			'save_btn_name'  => 'uap_automator_purgedays_save',
			'save_btn_title' => __( 'Save', 'uncanny-automator-pro' ),
			'fields'         => [
				'uap_automator_purge_days' => [
					'title'           => __( 'Enter value in days', 'uncanny-automator-pro' ),
					'type'            => 'number',
					'css_classes'     => '',
					'name'            => 'uap_automator_purge_days',
					'placeholder'     => '10',
					'default'         => '10',
					'required'        => true,
					'custom_atts'     => [
						'min'  => 0,
						'max'  => 365,
						'step' => 1,
					],
					'validation_func' => '',
				]
			],
		];

		return $tabs;
	}

	/**
	 * Delete old logs.
	 */
	public function delete_old_logs() {
		global $wpdb;

		$purge_days_limit = get_option( 'uap_automator_purge_days' );
		if ( intval( $purge_days_limit ) > 0 ) {
			$previous_time = date( 'Y-m-d', strtotime( '-' . $purge_days_limit . ' day' ) );
			$query         = "SELECT * FROM {$wpdb->prefix}uap_recipe_log WHERE date_time < '{$previous_time}' AND completed = 1 ";

			$recipes = $wpdb->get_results( $query );
			if ( ! empty( $recipes ) ) {
				foreach ( $recipes as $recipe ) {

					$args = array(
						'post_parent' => $recipe->automator_recipe_id,
						'post_status' => 'any',
						'post_type'   => 'uo-trigger',
						'numberposts' => 99,
					);

					$children = get_children( $args );

					if ( is_array( $children ) && count( $children ) > 0 ) {

						// Delete all the Children logs.
						foreach ( $children as $child ) {
							\Uncanny_Automator\Recipe_Post_Type::delete_trigger_logs( $child->ID );
						}
					}

					$args = array(
						'post_parent' => $recipe->automator_recipe_id,
						'post_status' => 'any',
						'post_type'   => 'uo-action',
						'numberposts' => 99,
					);

					$children = get_children( $args );

					if ( is_array( $children ) && count( $children ) > 0 ) {

						// Delete all the Children logs.
						foreach ( $children as $child ) {

							\Uncanny_Automator\Recipe_Post_Type::delete_action_logs( $child->ID );
						}
					}
					$args = array(
						'post_parent' => $recipe->automator_recipe_id,
						'post_status' => 'any',
						'post_type'   => 'uo-closure',
						'numberposts' => 99,
					);

					$children = get_children( $args );

					if ( is_array( $children ) && count( $children ) > 0 ) {

						// Delete all the Children of the Parent Page.
						foreach ( $children as $child ) {

							\Uncanny_Automator\Recipe_Post_Type::delete_closure_logs( $child->ID );
						}
					}
				}
			}
		}
	}

}

