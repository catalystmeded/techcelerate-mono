<?php

namespace Uncanny_Automator_Pro;

/**
 * Class ANON_FI_SUBMITFORM
 * @package Uncanny_Automator_Pro
 */
class ANON_FI_SUBMITFORM {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'FI';

	/**
	 * @var string
	 */
	private $trigger_code;
	/**
	 * @var string
	 */
	private $trigger_meta;

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {
		$this->trigger_code = 'ANONFISUBMITFORM';
		$this->trigger_meta = 'ANONFIFORM';
		$this->define_trigger();
	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function define_trigger() {

		global $uncanny_automator;

		$trigger = array(
			'author'              => $uncanny_automator->get_author_name(),
			'support_link'        => $uncanny_automator->get_author_support_link(),
			'integration'         => self::$integration,
			'code'                => $this->trigger_code,
			/* translators: Anonymous trigger - Formidable */
			'sentence'            => sprintf( __( '{{A form:%1$s}} is submitted', 'uncanny-automator-pro' ), $this->trigger_meta ),
			/* translators: Anonymous trigger - Formidable */
			'select_option_name'  => __( '{{A form}} is submitted', 'uncanny-automator-pro' ),
			'type'                => 'anonymous',
			'action'              => 'frm_after_create_entry',
			'priority'            => 20,
			'accepted_args'       => 2,
			'validation_function' => array( $this, 'fi_submit_form' ),
			'options'             => [
				$uncanny_automator->helpers->recipe->formidable->options->all_formidable_forms( null, $this->trigger_meta ),
			],
		);

		$uncanny_automator->register->trigger( $trigger );

		return;
	}

	/**
	 * Validation function when the trigger action is hit
	 *
	 * @param $entry_id
	 * @param $form_id
	 */
	public function fi_submit_form( $entry_id, $form_id ) {

		global $uncanny_automator;

		$user_id = get_current_user_id();

		$args = [
			'code'    => $this->trigger_code,
			'meta'    => $this->trigger_meta,
			'post_id' => intval( $form_id ),
			'user_id' => intval( $user_id ),
		];

		$result = $uncanny_automator->maybe_add_trigger_entry( $args, false );

		if ( $result ) {
			foreach ( $result as $r ) {
				if ( true === $r['result'] ) {
					if ( isset( $r['args'] ) && isset( $r['args']['get_trigger_id'] ) ) {
						//Saving form values in trigger log meta for token parsing!
						$fi_args = [
							'trigger_id'     => (int) $r['args']['trigger_id'],
							'meta_key'       => $this->trigger_meta,
							'user_id'        => $user_id,
							'trigger_log_id' => $r['args']['get_trigger_id'],
							'run_number'     => $r['args']['run_number'],
						];

						$uncanny_automator->helpers->recipe->formidable->pro->extract_save_fi_fields( $entry_id, $form_id, $fi_args );
					}
					$uncanny_automator->maybe_trigger_complete( $r['args'] );
				}
			}
		}

	}

	/**
	 * @param $metas
	 * @param $form_id
	 * @param $trigger_id
	 *
	 * @return array
	 */
	public function extract_fi_fields( $metas, $form_id, $trigger_id ) {
		$data = [];
		if ( $metas ) {
			foreach ( $metas as $meta ) {
				$field_id     = $meta->field_id;
				$key          = "{$trigger_id}:{$this->trigger_meta}:{$form_id}|{$field_id}";
				$data[ $key ] = $meta->meta_value;
			}
		}

		return $data;
	}
}
