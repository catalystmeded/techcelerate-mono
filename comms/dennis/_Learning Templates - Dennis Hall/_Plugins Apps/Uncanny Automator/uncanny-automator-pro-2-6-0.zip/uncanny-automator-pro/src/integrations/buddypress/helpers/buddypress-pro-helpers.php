<?php


namespace Uncanny_Automator_Pro;


use Uncanny_Automator\Buddypress_Helpers;

/**
 * Class Buddypress_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Buddypress_Pro_Helpers extends Buddypress_Helpers {
	/**
	 * Buddypress_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Buddypress_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}
	}

	/**
	 * @param Buddypress_Pro_Helpers $pro
	 */
	public function setPro( Buddypress_Pro_Helpers $pro ) {
		parent::setPro( $pro );
	}
}