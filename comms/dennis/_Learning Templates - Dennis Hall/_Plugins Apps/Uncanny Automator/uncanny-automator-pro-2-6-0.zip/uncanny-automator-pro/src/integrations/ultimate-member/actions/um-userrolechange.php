<?php

namespace Uncanny_Automator_Pro;

use WP_User;

/**
 * Class WP_SETPOSTMETA
 * @package Uncanny_Automator_Pro
 */
class UM_USERROLECHANGE {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'UM';

	private $action_code;
	private $action_meta;

	/**
	 * Set up Automator action constructor.
	 */
	public function __construct() {
		$this->action_code = 'UMUSERROLECHANGE';
		$this->action_meta = 'WPROLE';
		if ( is_admin() ) {
			add_action( 'wp_loaded', array( $this, 'plugins_loaded' ), 99 );
		} else {
			$this->define_action();
		}
	}

	public function plugins_loaded() {
		$this->define_action();
	}

	/**
	 * Define and register the action by pushing it into the Automator object
	 */

	/**
	 * Define and register the action by pushing it into the Automator object
	 */
	public function define_action() {
		global $uncanny_automator;
		$action = array(
			'author'             => $uncanny_automator->get_author_name(),
			'support_link'       => $uncanny_automator->get_author_support_link(),
			'integration'        => self::$integration,
			'code'               => $this->action_code,
			/* translators: Action - Ultimate Member */
			'sentence'           => sprintf( __( 'Set the user\'s role to {{a specific role:%1$s}}', 'uncanny-automator-pro' ), $this->action_meta ),
			/* translators: Action - Ultimate Member */
			'select_option_name' => __( 'Set the user\'s role to {{a specific role}}', 'uncanny-automator-pro' ),
			'priority'           => 11,
			'accepted_args'      => 3,
			'execution_function' => array( $this, 'user_role' ),
			'options'            => [
				$uncanny_automator->helpers->recipe->wp->options->wp_user_roles(),
			],
		);

		$uncanny_automator->register->action( $action );
	}

	/**
	 * Validation function when the trigger action is hit
	 *
	 * @param $user_id
	 * @param $action_data
	 * @param $recipe_id
	 */
	public function user_role( $user_id, $action_data, $recipe_id ) {

		global $uncanny_automator;

		$role = $action_data['meta'][ $this->action_meta ];

		$user_obj   = new WP_User( (int) $user_id );
		$user_roles = $user_obj->roles;
		if ( ! in_array( 'administrator', $user_roles ) ) {
			$user_obj->set_role( $role );
			$uncanny_automator->complete_action( $user_id, $action_data, $recipe_id );
		} else {
			$error_message = __( 'For security, the change role action cannot be applied to administrators.', 'uncanny-automator-pro' );
			$uncanny_automator->complete_action( $user_id, $action_data, $recipe_id, $error_message );
		}
	}

}
