<?php

namespace Uncanny_Automator_Pro;

use Twilio\Exceptions\ConfigurationException;
use Twilio\Exceptions\RestException;
use Twilio\Exceptions\TwilioException;
use Twilio\Rest\Client;

/**
 * Class Twilio_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Twilio_Pro_Helpers {

	/**
	 * @var Twilio_Pro_Helpers
	 */
	public $options;

	/**
	 * @var Twilio_Pro_Helpers
	 */
	public $pro;

	/**
	 * @var string
	 */
	public $setting_tab;
	/**
	 * @var bool
	 */
	public $load_options;

	/**
	 * Twilio_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( method_exists( '\Uncanny_Auatomator\Automator_Helpers_Recipe', 'maybe_load_trigger_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}

		$this->setting_tab = 'twilio_api';
		add_filter( 'uap_settings_tabs', [ $this, 'add_twilio_api_settings' ], 15 );
		add_action( 'update_option_uap_automator_twilio_api_auth_token', [ $this, 'twilio_oauth_update' ], 100, 3 );
		add_action( 'add_option_uap_automator_twilio_api_auth_token', [ $this, 'twilio_oauth_new' ], 100, 2 );
		add_action( 'init', [ $this, 'twilio_oauth_save' ], 200 );
	}

	/**
	 * @param Twilio_Pro_Helpers $options
	 */
	public function setOptions( Twilio_Pro_Helpers $options ) {
		$this->options = $options;
	}

	/**
	 * @param Twilio_Pro_Helpers $pro
	 */
	public function setPro( Twilio_Pro_Helpers $pro ) {
		$this->pro = $pro;
	}

	/**
	 *
	 * @param string $to
	 * @param string $message
	 * @param string $user_id
	 *
	 * @return array
	 * @throws ConfigurationException
	 * @throws TwilioException
	 */
	public function send_sms( $to, $message, $user_id ) {
		list( $account_sid, $auth_token ) = self::get_twilio_token();

		if ( empty( $account_sid ) || empty( $auth_token ) ) {
			return [ 'result' => false, 'message' => __( 'Twilio credentails has expired.', 'uncanny-automator-pro' ) ];
		}

		$phone_number = trim( get_option( 'uap_automator_twilio_api_phone_number', '' ) );
		if ( empty( $phone_number ) ) {
			return [ 'result' => false, 'message' => __( 'Twilio number is missing.', 'uncanny-automator-pro' ) ];
		}

		$to = self::validate_phone_number( $to );
		if ( ! $to ) {
			return [ 'result' => false, 'message' => __( 'To number is not valid.', 'uncanny-automator-pro' ) ];
		}

		try {
			$twilio  = new Client( $account_sid, $auth_token );
			$message = $twilio->messages->create( $to,
				[
					"body" => $message,
					"from" => $phone_number,
				]
			);

			update_user_meta( $user_id, '_twilio_sms_', $message->sid );

			return [ 'result' => true, 'message' => "" ];
		} catch ( RestException $exception ) {
			return [ 'result' => false, 'message' => __( $exception->getMessage(), 'uncanny-automator-pro' ) ];
		}

	}

	/**
	 * @param $phone
	 *
	 * @return false|mixed|string|string[]
	 */
	private function validate_phone_number( $phone ) {
		// Allow +, - and . in phone number
		$filtered_phone_number = filter_var( $phone, FILTER_SANITIZE_NUMBER_INT );
		// Remove "-" from number
		$phone_to_check = str_replace( "-", "", $filtered_phone_number );

		// Check the lenght of number
		// This can be customized if you want phone number from a specific country
		if ( strlen( $phone_to_check ) < 10 || strlen( $phone_to_check ) > 14 ) {
			return false;
		} else {
			return $phone_to_check;
		}
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function add_twilio_api_settings( $tabs ) {
		$is_uncannyowl_twilio_settings_expired = get_option( '_uncannyowl_twilio_settings_expired', false );
		$tab_url                               = admin_url( 'edit.php' ) . '?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab;
		$tabs[ $this->setting_tab ]            = [
			'name'           => __( 'Twilio', 'uncanny-automator-pro' ),
			'title'          => __( 'Twilio API settings', 'uncanny-automator-pro' ),
			'description'    => __( '<p>To view API credentials visit <a href="https://www.twilio.com/user/account/voice-sms-mms" target="_blank">https://www.twilio.com/user/account/voice-sms-mms</a>. It\'s really easy, we promise! Visit <a href="https://automatorplugin.com/knowledge-base/twilio/" target="_blank">https://automatorplugin.com/knowledge-base/twilio/</a> for simple instructions.</p>', 'uncanny-automator-pro' ),
			'is_pro'         => true,
			'is_expired'     => $is_uncannyowl_twilio_settings_expired,
			'settings_field' => 'uap_automator_twilio_api_settings',
			'wp_nonce_field' => 'uap_automator_twilio_api_nonce',
			'save_btn_name'  => 'uap_automator_twilio_api_save',
			'save_btn_title' => __( 'Save API details', 'uncanny-automator-pro' ),
			'fields'         => [
				'uap_automator_twilio_api_account_sid'  => [
					'title'       => __( 'Account SID:', 'uncanny-automator-pro' ),
					'type'        => 'text',
					'css_classes' => '',
					'placeholder' => '',
					'default'     => '',
					'required'    => true,
					'custom_atts' => [ 'autocomplete' => 'off' ],
				],
				'uap_automator_twilio_api_auth_token'   => [
					'title'       => __( 'Auth Token:', 'uncanny-automator-pro' ),
					'type'        => 'text',
					'css_classes' => '',
					'placeholder' => '',
					'default'     => '',
					'required'    => true,
					'custom_atts' => [ 'autocomplete' => 'off' ],
				],
				'uap_automator_twilio_api_phone_number' => [
					'title'       => __( 'Twilio Number:', 'uncanny-automator-pro' ),
					'type'        => 'text',
					'css_classes' => '',
					'placeholder' => '+15017122661',
					'default'     => '',
					'required'    => true,
					'custom_atts' => [ 'autocomplete' => 'off' ],
				],
			],
		];

		return $tabs;
	}

	/**
	 * To get twilio access tokens
	 *
	 * @return array
	 * @throws ConfigurationException
	 * @throws TwilioException
	 */
	public static function get_twilio_token() {

		$get_transient = get_transient( '_uncannyowl_twilio_settings' );

		if ( false !== $get_transient ) {

			$tokens = explode( '|', $get_transient );

			return [ $tokens[0], $tokens[1] ];

		} else {

			$oauth_settings        = get_option( '_uncannyowl_twilio_settings' );
			$current_refresh_token = isset( $oauth_settings['account_sid'] ) ? $oauth_settings['account_sid'] : '';
			if ( empty( $current_refresh_token ) ) {
				update_option( '_uncannyowl_twilio_settings_expired', true );

				return [ '', '' ];
			}

			$account_sid  = trim( get_option( 'uap_automator_twilio_api_account_sid', '' ) );
			$auth_token   = trim( get_option( 'uap_automator_twilio_api_auth_token', '' ) );
			$phone_number = trim( get_option( 'uap_automator_twilio_api_phone_number', '' ) );
			if ( isset( $account_sid ) && isset( $auth_token )
			     && strlen( $account_sid ) > 0
			     && strlen( $auth_token ) > 0
			     && strlen( $phone_number ) > 0
			     && strlen( $phone_number ) > 0
			) {
				try {
					$client                      = new Client( $account_sid, $auth_token );
					$account                     = $client->account->fetch();
					$tokens_info                 = [];
					$tokens_info['account_sid']  = $account_sid;
					$tokens_info['auth_token']   = $auth_token;
					$tokens_info['phone_number'] = $phone_number;
					update_option( '_uncannyowl_twilio_settings', $tokens_info );
					set_transient( '_uncannyowl_twilio_settings', $tokens_info['account_sid'] . '|' . $tokens_info['auth_token'], 60 * 50 );
					delete_option( '_uncannyowl_twilio_settings_expired' );

					return [ $account_sid, $auth_token ];
				} catch ( RestException $exception ) {
					update_option( '_uncannyowl_twilio_settings', [] );
					update_option( '_uncannyowl_twilio_settings_expired', true );

					return [ '', '' ];
				}
			} else {
				// Empty settings
				update_option( '_uncannyowl_twilio_settings', [] );
				update_option( '_uncannyowl_twilio_settings_expired', true );

				return [ '', '' ];
			}
		}
	}

	/**
	 * Action when settings updated, it will redirect user to 3rd party for OAuth connect.
	 *
	 * @param string|array $old_value
	 * @param string|array $new_value
	 * @param string $option
	 *
	 * @throws ConfigurationException
	 * @throws TwilioException
	 */
	public function twilio_oauth_update( $old_value, $new_value, $option ) {
		if ( $option === 'uap_automator_twilio_api_auth_token' && $old_value !== $new_value ) {
			$this->oauth_redirect();
		}
	}

	/**
	 * Action when settings added, it will redirect user to 3rd party for OAuth connect.
	 *
	 * @param string|array $old_value
	 * @param string|array $new_value
	 * @param string $option
	 */
	public function twilio_oauth_new( $option, $new_value ) {
		if ( $option === 'uap_automator_twilio_api_auth_token' && ! empty( $new_value ) ) {
			$this->oauth_redirect();
		}
	}

	/**
	 * Action when settings added, it will redirect user to 3rd party for OAuth connect.
	 */
	public function twilio_oauth_save() {
		if ( isset( $_POST['uap_automator_twilio_api_account_sid'] ) && ! empty( $_POST['uap_automator_twilio_api_account_sid'] ) && isset( $_POST['uap_automator_twilio_api_auth_token'] ) && ! empty( $_POST['uap_automator_twilio_api_auth_token'] ) ) {
			update_option( 'uap_automator_twilio_api_account_sid', $_POST['uap_automator_twilio_api_account_sid'] );
			update_option( 'uap_automator_twilio_api_auth_token', $_POST['uap_automator_twilio_api_auth_token'] );
			update_option( 'uap_automator_twilio_api_phone_number', $_POST['uap_automator_twilio_api_phone_number'] );
			$this->oauth_redirect();
		}
	}

	/**
	 * @throws ConfigurationException
	 * @throws TwilioException
	 */
	private function oauth_redirect() {
		$account_sid  = trim( get_option( 'uap_automator_twilio_api_account_sid', '' ) );
		$auth_token   = trim( get_option( 'uap_automator_twilio_api_auth_token', '' ) );
		$phone_number = trim( get_option( 'uap_automator_twilio_api_phone_number', '' ) );
		if ( isset( $account_sid ) && isset( $auth_token ) && strlen( $account_sid ) > 0 && strlen( $auth_token ) > 0 && strlen( $phone_number ) > 0 && strlen( $phone_number ) > 0 ) {
			try {
				$client                      = new Client( $account_sid, $auth_token );
				$account                     = $client->account->fetch();
				$tokens_info                 = [];
				$tokens_info['account_sid']  = $account_sid;
				$tokens_info['auth_token']   = $auth_token;
				$tokens_info['phone_number'] = $phone_number;
				update_option( '_uncannyowl_twilio_settings', $tokens_info );
				set_transient( '_uncannyowl_twilio_settings', $tokens_info['account_sid'] . '|' . $tokens_info['auth_token'], 60 * 50 );
				delete_option( '_uncannyowl_twilio_settings_expired' );
				wp_safe_redirect( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab . '&connect=1' ) );
				die;
			} catch ( RestException $exception ) {
				wp_safe_redirect( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab . '&connect=2' ) );
				die;
			}
		}
	}

	/**
	 * @param string $option_code
	 * @param string $label
	 * @param bool $tokens
	 * @param string $type
	 * @param string $default
	 * @param bool
	 * @param string $description
	 * @param string $placeholder
	 *
	 * @return mixed
	 */
	public function textarea_field( $option_code = 'TEXT', $label = null, $tokens = true, $type = 'text', $default = null, $required = true, $description = '', $placeholder = null ) {

		if ( ! $label ) {
			$label = __( 'Text', 'uncanny-automator-pro' );
		}

		if ( ! $description ) {
			$description = '';
		}

		if ( ! $placeholder ) {
			$placeholder = '';
		}

		$option = [
			'option_code'      => $option_code,
			'label'            => $label,
			'description'      => $description,
			'placeholder'      => $placeholder,
			'input_type'       => $type,
			'supports_tokens'  => $tokens,
			'required'         => $required,
			'default_value'    => $default,
			'supports_tinymce' => false,
		];

		return apply_filters( 'uap_option_text_field', $option );
	}
}