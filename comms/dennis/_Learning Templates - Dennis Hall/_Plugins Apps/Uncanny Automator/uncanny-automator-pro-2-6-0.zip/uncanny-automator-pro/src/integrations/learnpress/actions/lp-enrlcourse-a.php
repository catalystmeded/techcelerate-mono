<?php

namespace Uncanny_Automator_Pro;

use LP_Order;

/**
 * Class LP_ENRLCOURSE_A
 * @package Uncanny_Automator_Pro
 */
class LP_ENRLCOURSE_A {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'LP';

	private $action_code;
	private $action_meta;

	/**
	 * Set up Automator action constructor.
	 */
	public function __construct() {
		$this->action_code = 'LPENRLCOURSE-A';
		$this->action_meta = 'LPCOURSE';
		$this->define_action();
	}

	/**
	 * Define and register the action by pushing it into the Automator object
	 */
	public function define_action() {

		global $uncanny_automator;

		$action = array(
			'author'             => $uncanny_automator->get_author_name( $this->action_code ),
			'support_link'       => $uncanny_automator->get_author_support_link( $this->action_code ),
			'integration'        => self::$integration,
			'code'               => $this->action_code,
			/* translators: Action - LearnPress */
			'sentence'           => sprintf( __( 'Enroll the user in {{a course:%1$s}}', 'uncanny-automator-pro' ), $this->action_meta ),
			/* translators: Action - LearnPress */
			'select_option_name' => __( 'Enroll the user in {{a course}}', 'uncanny-automator-pro' ),
			'priority'           => 10,
			'accepted_args'      => 3,
			'execution_function' => array( $this, 'lp_enroll_in_course' ),
			'options'            => [
				$uncanny_automator->helpers->recipe->learnpress->options->all_lp_courses( null, 'LPCOURSE', false ),
			],
		);

		$uncanny_automator->register->action( $action );
	}

	/**
	 * Validation function when the action is hit
	 *
	 * @param $user_id
	 * @param $action_data
	 * @param $recipe_id
	 */
	public function lp_enroll_in_course( $user_id, $action_data, $recipe_id ) {

		global $uncanny_automator;

		if ( ! function_exists( 'learn_press_get_user' ) ) {
			$error_message = __( 'The function learn_press_get_user does not exist', 'uncanny-automator-pro' );
			$uncanny_automator->complete_action( $user_id, $action_data, $recipe_id, $error_message );

			return;
		}

		//loading LP user by user_id
		$user     = learn_press_get_user( $user_id );
		$order_id = 0;

		$course_id = $action_data['meta'][ $this->action_meta ];
		// loading LP course by ID
		$course  = learn_press_get_course( $course_id );
		$is_paid = ! $course->is_free();
		if ( $is_paid ) {
			$order = new LP_Order();
			$order->set_customer_note( __( 'Order created by Uncanny Automator', 'uncanny-automator-pro' ) );
			$order->set_status( 'lp-completed' );
			$order->set_total( 0 );
			$order->set_subtotal( 0 );
			$order->set_user_ip_address( learn_press_get_ip() );
			$order->set_user_agent( learn_press_get_user_agent() );
			$order->set_created_via( 'Uncanny Automator' );
			$order->set_user_id( $user_id );

			$order_id = $order->save();

			$order_item                    = [];
			$order_item['order_item_name'] = $course->get_title();
			$order_item['item_id']         = $course_id;
			$order_item['quantity']        = 1;
			$order_item['subtotal']        = 0;
			$order_item['total']           = 0;
			$order->add_item( $order_item, 1 );
		}
		//Enroll to New Course
		if ( $course && $course->exists() ) {
			$enrol_result = $user->enroll( $course_id, $order_id, true );
			delete_transient( 'checkout_enroll_course_id' );
		}
		$uncanny_automator->complete_action( $user_id, $action_data, $recipe_id );
	}
}
