<?php


namespace Uncanny_Automator_Pro;


use Uncanny_Automator\Woocommerce_Helpers;

/**
 * Class Woocommerce_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Woocommerce_Pro_Helpers extends Woocommerce_Helpers {

	/**
	 * @var bool
	 */
	public $load_options;

	/**
	 * Woocommerce_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Woocommerce_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		} else {
			$this->load_options = true;
		}

		add_action( 'wp_ajax_select_variations_from_WOOSELECTVARIATION', [
			$this,
			'select_all_product_variations'
		] );
	}

	/**
	 * @param Woocommerce_Pro_Helpers $pro
	 */
	public function setPro( Woocommerce_Pro_Helpers $pro ) {
		$this->pro = $pro;
	}

	/**
	 * @param string $label
	 * @param string $option_code
	 *
	 * @return mixed
	 */
	public function all_wc_subscriptions( $label = null, $option_code = 'WOOSUBSCRIPTIONS' ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}


		if ( ! $label ) {
			$label = __( 'Select a Subscription', 'uncanny-automator-pro' );
		}

		global $wpdb;
		$q = "
			SELECT posts.ID, posts.post_title FROM $wpdb->posts as posts
			LEFT JOIN $wpdb->term_relationships as rel ON (posts.ID = rel.object_id)
			WHERE rel.term_taxonomy_id IN (SELECT term_id FROM $wpdb->terms WHERE slug IN ('subscription','variable-subscription'))
			AND posts.post_type = 'product'
			AND posts.post_status = 'publish'
			UNION ALL
			SELECT ID, post_title FROM $wpdb->posts
			WHERE post_type = 'shop_subscription'
			AND post_status = 'publish'
			ORDER BY post_title
		";

		// Query all subscription products based on the assigned product_type category (new WC type) and post_type shop_"
		$subscriptions = $wpdb->get_results( $q );

		$options       = [];
		$options['-1'] = __( 'Any Subscription', 'uncanny-automator-pro' );

		foreach ( $subscriptions as $post ) {
			$title = $post->post_title;

			if ( empty( $title ) ) {
				$title = sprintf( __( 'ID: %s (no title)', 'uncanny-automator-pro' ), $post->ID );
			}

			$options[ $post->ID ] = $title;
		}

		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'options'         => $options,
			'relevant_tokens' => [
				$option_code          => __( 'Product Title', 'uncanny-automator' ),
				$option_code . '_ID'  => __( 'Product ID', 'uncanny-automator' ),
				$option_code . '_URL' => __( 'Product URL', 'uncanny-automator' ),
			],
		];

		return apply_filters( 'uap_option_all_wc_subscriptions', $option );
	}

	/**
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function all_wc_variable_products( $label = null, $option_code = 'WOO‎‎VARIABLEPRODUCTS', $args = [] ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}


		if ( ! $label ) {
			$label = __( 'Product', 'uncanny-automator' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';

		global $wpdb;
		$query = "
			SELECT posts.ID, posts.post_title FROM $wpdb->posts as posts
			LEFT JOIN $wpdb->term_relationships as rel ON (posts.ID = rel.object_id)
			WHERE rel.term_taxonomy_id IN (SELECT term_id FROM $wpdb->terms WHERE slug IN ('variable'))
			AND posts.post_type = 'product'
			AND posts.post_status = 'publish'
			ORDER BY post_title
		";

		$all_products  = $wpdb->get_results( $query );
		$options       = [];
		$options['-1'] = __( 'Any Product', 'uncanny-automator' );

		foreach ( $all_products as $product ) {
			$title = $product->post_title;
			if ( empty( $title ) ) {
				$title = sprintf( __( 'ID: %s (no title)', 'uncanny-automator-pro' ), $product->ID );
			}
			$options[ $product->ID ] = $title;
		}

		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
			'relevant_tokens' => [
				$option_code          => __( 'Product title', 'uncanny-automator' ),
				$option_code . '_ID'  => __( 'Product ID', 'uncanny-automator' ),
				$option_code . '_URL' => __( 'Product URL', 'uncanny-automator' ),
			],
		];

		return apply_filters( 'uap_option_all_wc_variable_products', $option );
	}

	/**
	 * @param null $label
	 * @param string $option_code
	 *
	 * @return mixed|void
	 */
	public function all_wc_product_categories( $label = null, $option_code = 'WOO‎‎PRODCAT' ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}


		if ( ! $label ) {
			$label = __( 'Categories', 'uncanny-automator-pro' );
		}

		global $wpdb;
		$query = "
			SELECT terms.term_id,terms.name FROM $wpdb->terms as terms
			LEFT JOIN $wpdb->term_taxonomy as rel ON (terms.term_id = rel.term_id)
			WHERE rel.taxonomy = 'product_cat'
			ORDER BY terms.name";

		$categories = $wpdb->get_results( $query );

		$options = [];

		foreach ( $categories as $category ) {
			$title = $category->name;
			if ( empty( $title ) ) {
				$title = sprintf( __( 'ID: %s (no title)', 'uncanny-automator-pro' ), $category->term_id );
			}
			$options[ $category->term_id ] = $title;
		}

		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'options'         => $options,
			'relevant_tokens' => [
				$option_code          => __( 'Category title', 'uncanny-automator' ),
				$option_code . '_ID'  => __( 'Category ID', 'uncanny-automator' ),
				$option_code . '_URL' => __( 'Category URL', 'uncanny-automator' ),
			],
		];

		return apply_filters( 'uap_option_all_wc_product_categories', $option );
	}


	/**
	 * @param null $label
	 * @param string $option_code
	 *
	 * @return mixed|void
	 */
	public function all_wc_product_tags( $label = null, $option_code = 'WOO‎‎PRODTAG' ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}

		if ( ! $label ) {
			$label = __( 'Categories', 'uncanny-automator-pro' );
		}

		global $wpdb;
		$query = "
			SELECT terms.term_id,terms.name FROM $wpdb->terms as terms
			LEFT JOIN $wpdb->term_taxonomy as rel ON (terms.term_id = rel.term_id)
			WHERE rel.taxonomy = 'product_tag'
			ORDER BY terms.name";

		$tags = $wpdb->get_results( $query );


		$options       = [];
		$options['-1'] = __( 'Any Tag', 'uncanny-automator-pro' );

		foreach ( $tags as $tag ) {
			$title = $tag->name;
			if ( empty( $title ) ) {
				$title = sprintf( __( 'ID: %s (no title)', 'uncanny-automator-pro' ), $tag->term_id );
			}
			$options[ $tag->term_id ] = $title;
		}

		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'options'         => $options,
			'relevant_tokens' => [
				$option_code          => __( 'Tag title', 'uncanny-automator' ),
				$option_code . '_ID'  => __( 'Tag ID', 'uncanny-automator' ),
				$option_code . '_URL' => __( 'Tag URL', 'uncanny-automator' ),
			],
		];

		return apply_filters( 'uap_option_all_wc_product_tags', $option );
	}

	/**
	 * get all variations of selected variable product
	 */
	public function select_all_product_variations() {
		global $uncanny_automator;

		// Nonce and post object validation
		$uncanny_automator->utilities->ajax_auth_check( $_POST );

		$fields = [];
		if ( isset( $_POST['value'] ) && ! empty( $_POST['value'] ) ) {

			$args = [
				'post_type'      => 'product_variation',
				'post_parent'    => absint( $_POST['value'] ),
				'posts_per_page' => 999,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'post_status'    => 'publish',
			];

			$options = get_posts( $args );

			if ( isset( $options ) && ! empty( $options ) ) {
				foreach ( $options as $option ) {
					$fields[] = [
						'value' => $option->ID,
						'text'  => $option->post_title,
					];
				}
			} else {
				$fields[] = [
					'value' => - 1,
					'text'  => __( 'Any Variation', 'uncanny-automator-pro' ),
				];
			}
		}
		echo wp_json_encode( $fields );
		die();
	}
}