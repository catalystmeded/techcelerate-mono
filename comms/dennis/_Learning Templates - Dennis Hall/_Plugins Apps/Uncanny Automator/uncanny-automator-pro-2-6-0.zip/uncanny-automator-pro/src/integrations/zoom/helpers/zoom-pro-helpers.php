<?php


namespace Uncanny_Automator_Pro;


/**
 * Class Zoom_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Zoom_Pro_Helpers {

	/**
	 * @var Zoom_Pro_Helpers
	 */
	public $options;
	/**
	 * @var Zoom_Pro_Helpers
	 */
	public $pro;
	/**
	 * @var Zoom_Pro_Helpers
	 */
	public $setting_tab;

	/**
	 * @var bool
	 */
	public $load_options;

	/**
	 * Zoom_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( method_exists( '\Uncanny_Auatomator\Automator_Helpers_Recipe', 'maybe_load_trigger_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		} else {
			$this->load_options = true;
		}
		
		$this->setting_tab = 'zoom_api';
		add_filter( 'uap_settings_tabs', [ $this, 'add_zoom_api_settings' ], 15 );
		add_action( 'update_option_uap_automator_zoom_api_consumer_secret', [ $this, 'zoom_oauth_update' ], 100, 3 );
		add_action( 'add_option_uap_automator_zoom_api_consumer_secret', [ $this, 'zoom_oauth_new' ], 100, 2 );
		add_action( 'init', [ $this, 'validate_oauth_tokens' ], 100, 3 );
		add_action( 'init', [ $this, 'zoom_oauth_save' ], 200 );
	}

	/**
	 * @param Zoom_Pro_Helpers $options
	 */
	public function setOptions( Zoom_Pro_Helpers $options ) {
		$this->options = $options;
	}

	/**
	 * @param Zoom_Pro_Helpers $pro
	 */
	public function setPro( Zoom_Pro_Helpers $pro ) {
		$this->pro = $pro;
	}


	/**
	 * @param string $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed
	 */
	public function zoom_get_meetings( $label = null, $option_code = 'ZOOMMEETINGS', $args = [] ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}

		if ( ! $label ) {
			$label = __( 'Meeting', 'uncanny-automator-pro' );
		}

		$args = wp_parse_args( $args,
			array(
				'uo_include_any' => false,
				'uo_any_label'   => __( 'Any Meeting', 'uncanny-automator-pro' ),
			)
		);

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$options      = [];
		global $uncanny_automator;

		if ( $uncanny_automator->helpers->recipe->load_helpers ) {
			list( $access_token, $refresh_token ) = self::get_meeting_token();

			$current_time            = current_time( 'Y-m-d\TH:i:s\Z' );
			$current_time_plus_years = date( 'Y-m-d\TH:i:s\Z', strtotime( '+2 year', strtotime( $current_time ) ) );
			// get meetings
			$json_feed = wp_remote_get( 'https://api.zoom.us/v2/users/me/meetings?page_number=1&page_size=300&type=upcoming', [
				'headers' => [
					'Authorization' => "Bearer " . $access_token,
				],
			] );

			$json_response = wp_remote_retrieve_response_code( $json_feed );

			// prepare meeting lists
			if ( $json_response === 200 ) {
				$jsondata = json_decode( wp_remote_retrieve_body( $json_feed ), true );
				if ( count( $jsondata['meetings'] ) > 0 ) {
					foreach ( $jsondata['meetings'] as $key1 => $meeting ) {
						$meeting_key                            = (string) $meeting['id'];
						$options[ $meeting_key . "-objectkey" ] = $meeting['topic'];
					}
				}
			}
		}
		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => 'select',
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
		];

		return apply_filters( 'uap_option_zoom_get_meetings', $option );
	}

	/**
	 * For registering user to meeting action method.
	 *
	 * @param string $user_id
	 * @param string $meeting_key
	 *
	 * @return array
	 */
	public static function zoom_register_user( $user_id, $meeting_key ) {
		$user = get_userdata( $user_id );
		if ( is_wp_error( $user ) ) {
			return [ 'result' => false, 'message' => __( "Zoom user not found.", 'uncanny-automator-pro' ) ];
		}
		$customer_first_name = $user->first_name;
		$customer_last_name  = $user->last_name;
		$customer_email      = $user->user_email;

		if ( ! empty( $customer_email ) ) {
			$customer_email_parts = explode( '@', $customer_email );
			$customer_first_name  = empty( $customer_first_name ) ? $customer_email_parts[0] : $customer_first_name;
			$customer_last_name   = empty( $customer_last_name ) ? $customer_email_parts[0] : $customer_last_name;
		}
		list( $access_token, $refresh_token ) = self::get_meeting_token();

		if ( empty( $access_token ) ) {
			return [ 'result' => false, 'message' => __( 'Zoom credentials has expired.', 'uncanny-automator-pro' ) ];
		}
		// API register call
		$response = wp_remote_post( "https://api.zoom.us/v2/meetings/{$meeting_key}/registrants", [
			'method'      => 'POST',
			'timeout'     => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => true,
			'headers'     => [
				'Authorization' => "Bearer " . $access_token,
				'Content-type'  => 'application/json',
			],
			'body'        => json_encode( [
				'first_name' => $customer_first_name,
				'last_name'  => $customer_last_name,
				'email'      => $customer_email,
			] ),
		] );

		if ( ! is_wp_error( $response ) ) {
			if ( 201 === wp_remote_retrieve_response_code( $response ) ) {
				$jsondata = json_decode( $response['body'], true, 512, JSON_BIGINT_AS_STRING );
				if ( isset( $jsondata['join_url'] ) ) {
					update_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_registrant_id', $jsondata['registrant_id'] );
					update_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_joinUrl', $jsondata['join_url'] );
					update_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_id', $jsondata['id'] );

					return [ 'result' => true, 'message' => __( 'Successfully registered', 'uncanny-automator-pro' ) ];
				}
			} else {
				$jsondata = json_decode( $response['body'], true, 512, JSON_BIGINT_AS_STRING );

				return [ 'result' => false, 'message' => __( $jsondata['message'], 'uncanny-automator-pro' ) ];
			}
		}

		return [ 'result' => false, 'message' => __( "The Zoom API returned an error.", 'uncanny-automator-pro' ) ];
	}

	/**
	 * For un-registering user to meeting action method.
	 *
	 * @param string $user_id
	 * @param string $meeting_key
	 *
	 * @return array
	 */
	public static function zoom_unregister_user( $user_id, $meeting_key ) {

		$user = get_userdata( $user_id );
		if ( is_wp_error( $user ) ) {
			return [ 'result' => false, 'message' => __( "Zoom user not found.", 'uncanny-automator-pro' ) ];

		}
		$customer_email = $user->user_email;

		list( $access_token, $refresh_token ) = self::get_meeting_token();

		if ( empty( $access_token ) ) {
			return [ 'result' => false, 'message' => __( 'Zoom credentails has expired.', 'uncanny-automator-pro' ) ];
		}

		$user_registrant_key = get_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_registrant_id', true );

		if ( empty( $user_registrant_key ) ) {
			return [
				'result'  => false,
				'message' => __( 'User was not registered for Zoom Meeting.', 'uncanny-automator-pro' )
			];
		}

		// API register call
		$response = wp_remote_post( "https://api.zoom.us/v2/meetings/{$meeting_key}/registrants/status", [
			'method'      => 'PUT',
			'timeout'     => 45,
			'redirection' => 5,
			'httpversion' => '1.0',
			'blocking'    => true,
			'headers'     => [
				'Authorization' => "Bearer " . $access_token,
				'Content-type'  => 'application/json',
			],
			'body'        => json_encode( [
				'action'      => 'cancel',
				'registrants' => [
					[
						'id'    => $user_registrant_key,
						'email' => $customer_email,
					],
				],
			] )
		] );

		if ( ! is_wp_error( $response ) ) {
			if ( 201 === wp_remote_retrieve_response_code( $response ) || 204 === wp_remote_retrieve_response_code( $response ) ) {
				delete_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_registrant_id' );
				delete_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_joinUrl' );
				delete_user_meta( $user_id, '_uncannyowl_zoom_meeting_' . $meeting_key . '_id' );

				return [ 'result' => true, 'message' => __( 'Successfully registered', 'uncanny-automator-pro' ) ];
			} else {
				$jsondata = json_decode( $response['body'], true, 512, JSON_BIGINT_AS_STRING );

				return [ 'result' => false, 'message' => __( $jsondata['message'], 'uncanny-automator-pro' ) ];
			}
		}

		return [ 'result' => false, 'message' => __( "The Zoom API returned an error.", 'uncanny-automator-pro' ) ];
	}

	/**
	 * @param $tabs
	 *
	 * @return mixed
	 */
	public function add_zoom_api_settings( $tabs ) {
		$is_uncannyowl_zoom_settings_expired = get_option( '_uncannyowl_zoom_settings_expired', false );
		$tab_url                             = admin_url( 'edit.php' ) . '?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab;
		$tabs[ $this->setting_tab ]          = [
			'name'           => __( 'Zoom Meeting', 'uncanny-automator-pro' ),
			'title'          => __( 'Zoom Meeting API settings', 'uncanny-automator-pro' ),
			'description'    => __( '<p>Connecting to Zoom requires setting up an application and getting 2 values from inside your account. It\'s really easy, we promise! Visit <a href="https://automatorplugin.com/knowledge-base/zoom/" target="_blank">https://automatorplugin.com/knowledge-base/zoom/</a> for simple instructions.</p> <p>When you are asked to enter a "Redirect URL for OAuth", use this: ' . $tab_url . '</p>', 'uncanny-automator-pro' ),
			'is_pro'         => true,
			'is_expired'     => $is_uncannyowl_zoom_settings_expired,
			'settings_field' => 'uap_automator_zoom_api_settings',
			'wp_nonce_field' => 'uap_automator_zoom_api_nonce',
			'save_btn_name'  => 'uap_automator_zoom_api_save',
			'save_btn_title' => __( 'Save API details', 'uncanny-automator-pro' ),
			'fields'         => [
				'uap_automator_zoom_api_consumer_key'    => [
					'title'       => __( 'Client ID:', 'uncanny-automator-pro' ),
					'type'        => 'text',
					'css_classes' => '',
					'placeholder' => '',
					'default'     => '',
					'required'    => true,
					'custom_atts' => [ 'autocomplete' => 'off' ],
				],
				'uap_automator_zoom_api_consumer_secret' => [
					'title'       => __( 'Client secret:', 'uncanny-automator-pro' ),
					'type'        => 'text',
					'css_classes' => '',
					'placeholder' => '',
					'default'     => '',
					'required'    => true,
					'custom_atts' => [ 'autocomplete' => 'off' ],
				],
			],
		];

		return $tabs;
	}

	/**
	 * To get meeting access token and organizer key
	 *
	 * @return array
	 */
	public static function get_meeting_token() {


		$get_transient = get_transient( '_uncannyowl_zoom_settings' );

		if ( false !== $get_transient ) {

			$tokens = explode( '|', $get_transient );

			return [ $tokens[0], $tokens[1] ];

		} else {

			$oauth_settings        = get_option( '_uncannyowl_zoom_settings' );
			$current_refresh_token = isset( $oauth_settings['refresh_token'] ) ? $oauth_settings['refresh_token'] : '';
			if ( empty( $current_refresh_token ) ) {
				update_option( '_uncannyowl_zoom_settings_expired', true );

				return [ '', '' ];
			}

			$consumer_key    = trim( get_option( 'uap_automator_zoom_api_consumer_key', '' ) );
			$consumer_secret = trim( get_option( 'uap_automator_zoom_api_consumer_secret', '' ) );
			//do response
			$response = wp_remote_post( 'https://zoom.us/oauth/token', [
				'headers' => [
					'Authorization' => 'Basic ' . base64_encode( $consumer_key . ':' . $consumer_secret ),
					'Content-Type'  => 'application/x-www-form-urlencoded; charset=utf-8',
				],
				'body'    => [
					'refresh_token' => $current_refresh_token,
					'grant_type'    => 'refresh_token',

				],
			] );

			if ( ! is_wp_error( $response ) ) {
				if ( 200 === wp_remote_retrieve_response_code( $response ) ) {

					//get new access token and refresh token
					$jsondata = json_decode( $response['body'], true );

					$tokens_info                  = [];
					$tokens_info['access_token']  = $jsondata['access_token'];
					$tokens_info['refresh_token'] = $jsondata['refresh_token'];
					$tokens_info['token_type']    = $jsondata['token_type'];
					$tokens_info['expires_in']    = $jsondata['expires_in'];
					$tokens_info['scope']         = $jsondata['scope'];

					update_option( '_uncannyowl_zoom_settings', $tokens_info );
					set_transient( '_uncannyowl_zoom_settings', $tokens_info['access_token'] . '|' . $tokens_info['refresh_token'], 60 * 50 );
					delete_option( '_uncannyowl_zoom_settings_expired' );

					//return the array
					return [ $tokens_info['access_token'], $tokens_info['refresh_token'] ];

				} else {
					// Empty settings
					update_option( '_uncannyowl_zoom_settings', [] );
					update_option( '_uncannyowl_zoom_settings_expired', true );

					return [ '', '' ];
				}
			} else {
				// Empty settings
				update_option( '_uncannyowl_zoom_settings', [] );
				update_option( '_uncannyowl_zoom_settings_expired', true );

				return [ '', '' ];
			}
		}
	}

	/**
	 * Action when settings updated, it will redirect user to 3rd party for OAuth connect.
	 *
	 * @param string|array $old_value
	 * @param string|array $new_value
	 * @param string $option
	 */
	public function zoom_oauth_update( $old_value, $new_value, $option ) {
		if ( $option === 'uap_automator_zoom_api_consumer_secret' && $old_value !== $new_value ) {
			$this->oauth_redirect();
		}
	}

	/**
	 * Action when settings added, it will redirect user to 3rd party for OAuth connect.
	 *
	 * @param string|array $old_value
	 * @param string|array $new_value
	 * @param string $option
	 */
	public function zoom_oauth_new( $option, $new_value ) {
		if ( $option === 'uap_automator_zoom_api_consumer_secret' && ! empty( $new_value ) ) {
			$this->oauth_redirect();
		}
	}

	/**
	 * Action when settings added, it will redirect user to 3rd party for OAuth connect.
	 */
	public function zoom_oauth_save() {
		if ( isset( $_POST['uap_automator_zoom_api_consumer_key'] ) && ! empty( $_POST['uap_automator_zoom_api_consumer_key'] ) && isset( $_POST['uap_automator_zoom_api_consumer_secret'] ) && ! empty( $_POST['uap_automator_zoom_api_consumer_secret'] ) ) {
			update_option( 'uap_automator_zoom_api_consumer_key', $_POST['uap_automator_zoom_api_consumer_key'] );
			update_option( 'uap_automator_zoom_api_consumer_secret', $_POST['uap_automator_zoom_api_consumer_secret'] );
			$this->oauth_redirect();
		}
	}

	/**
	 *
	 */
	private function oauth_redirect() {
		$consumer_key    = trim( get_option( 'uap_automator_zoom_api_consumer_key', '' ) );
		$consumer_secret = trim( get_option( 'uap_automator_zoom_api_consumer_secret', '' ) );
		if ( isset( $consumer_key ) && isset( $consumer_secret ) && strlen( $consumer_key ) > 0 && strlen( $consumer_secret ) > 0 ) {
			$tab_url    = admin_url( 'edit.php' ) . '?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab;
			$oauth_link = "https://zoom.us/oauth/authorize?response_type=code&client_id=" . $consumer_key . "&state=" . urlencode( $this->setting_tab ) . '&redirect_uri=' . urlencode( $tab_url );
			wp_redirect( $oauth_link );
			die;
		}
	}

	/**
	 * Callback function for OAuth redirect verification.
	 */
	public function validate_oauth_tokens() {

		if ( isset( $_REQUEST['code'] ) && ! empty( $_REQUEST['code'] ) && isset( $_REQUEST['state'] ) && $_REQUEST['state'] === $this->setting_tab ) {
			$consumer_key    = trim( get_option( 'uap_automator_zoom_api_consumer_key', '' ) ); //msAteMmZCVflQDKK6TUsOJOKIfRFDyEL
			$consumer_secret = trim( get_option( 'uap_automator_zoom_api_consumer_secret', '' ) );//'kqUuc9tdfPEK0yLB
			$code            = $_REQUEST['code'];
			$tab_url         = admin_url( 'edit.php' ) . '?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab;
			$response        = wp_remote_post( 'https://zoom.us/oauth/token', [
				'headers' => [
					'Content-Type'  => 'application/x-www-form-urlencoded; charset=utf-8',
					'Authorization' => 'Basic ' . base64_encode( $consumer_key . ':' . $consumer_secret ),
					'Accept'        => 'application/json',
				],
				'body'    => [
					'code'         => $code,
					'grant_type'   => 'authorization_code',
					'redirect_uri' => $tab_url,
				],
			] );

			if ( ! is_wp_error( $response ) ) {
				// On success
				if ( 200 === wp_remote_retrieve_response_code( $response ) ) {

					//lets get the response and decode it
					$jsondata = json_decode( $response['body'], true );

					$tokens_info                  = [];
					$tokens_info['access_token']  = $jsondata['access_token'];
					$tokens_info['refresh_token'] = $jsondata['refresh_token'];
					$tokens_info['token_type']    = $jsondata['token_type'];
					$tokens_info['expires_in']    = $jsondata['expires_in'];
					$tokens_info['scope']         = $jsondata['scope'];

					//update the options
					update_option( '_uncannyowl_zoom_settings', $tokens_info );
					delete_option( '_uncannyowl_zoom_settings_expired' );
					//set the transient
					set_transient( '_uncannyowl_zoom_settings', $tokens_info['access_token'] . '|' . $tokens_info['refresh_token'], 60 * 50 );
					wp_safe_redirect( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab . '&connect=1' ) );
					die;

				} else {
					// On Error
					wp_safe_redirect( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab . '&connect=2' ) );
					die;
				}
			} else {
				// On Error
				wp_safe_redirect( admin_url( 'edit.php?post_type=uo-recipe&page=uncanny-automator-settings&tab=' . $this->setting_tab . '&connect=2' ) );
				die;
			}
		}
	}
}