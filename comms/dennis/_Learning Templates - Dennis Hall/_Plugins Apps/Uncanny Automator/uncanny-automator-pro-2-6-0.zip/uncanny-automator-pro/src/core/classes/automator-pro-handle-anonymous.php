<?php


namespace Uncanny_Automator_Pro;


/**
 * Class Automator_Pro_Handle_Anonymous
 * @package Uncanny_Automator_Pro
 */
class Automator_Pro_Handle_Anonymous {

	/**
	 * Automator_Pro_Handle_Anonymous constructor.
	 */
	public function __construct() {
		add_filter( 'uap_meta_box_title', [ $this, 'uap_meta_box_title_func' ], 10, 2 );
		add_filter( 'uap_localized_strings', [ $this, 'uap_localized_strings_func' ], 10 );
		add_filter( 'uap_recipe_types', [ $this, 'uap_recipe_types_func' ], 10 );
		add_filter( 'uap_error_messages', [ $this, 'uap_error_messages_func' ], 10 );
	}

	/**
	 * @param $default
	 * @param $recipe_type
	 *
	 * @return string|void
	 */
	public function uap_meta_box_title_func( $default, $recipe_type ) {
		if ( 'anonymous' === (string) $recipe_type ) {
			/* translators: Anonymous triggers can be triggered by logged-in or anonymous users. Anonymous recipes can create new users or modify existing users. */
			return __( 'Anonymous trigger', 'uncanny-automator-pro' );
		}

		return $default;
	}

	/**
	 * @param $strings
	 *
	 * @return mixed
	 */
	public function uap_localized_strings_func( $strings ) {
		/* translators: Anonymous triggers can be triggered by logged-in or anonymous users. Anonymous recipes can create new users or modify existing users. */
		$strings['trigger']['anonymousTrigger'] = __( 'Anonymous trigger', 'uncanny-automator-pro' );
		// UncannyAutomator.i18n.trigger.anonymousTrigger
		$strings['recipeType']['anonymousRecipeName'] = _x( 'Anonymous', 'Recipe type', 'uncanny-automator-pro' );
		// UncannyAutomator.i18n.recipeType.anonymousRecipeName
		$strings['recipeType']['anonymousRecipeDescription'] = __( 'Triggered by logged-in or anonymous users; supports single trigger; creates new user/modifies existing user', 'uncanny-automator-pro' );
		// UncannyAutomator.i18n.recipeType.anonymousRecipeDescription
		$strings['recipeType']['anonymousOnlyOneTrigger'] = __( 'Anonymous recipes only support a single trigger per recipe.', 'uncanny-automator-pro' );

		// UncannyAutomator.i18n.recipeType.anonymousOnlyOneTrigger

		return $strings;
	}

	/**
	 * @param $recipe_types
	 *
	 * @return array
	 */
	public function uap_recipe_types_func( $recipe_types ) {
		$recipe_types[] = 'anonymous';

		return $recipe_types;
	}

	/**
	 * @param $error_messages
	 *
	 * @return mixed
	 */
	public function uap_error_messages_func( $error_messages ) {

		$error_messages['anon-user-action-do-nothing'] = __( 'Anonymous recipe user action set to do nothing.', 'uncanny-automator-pro' );

		return $error_messages;
	}
}