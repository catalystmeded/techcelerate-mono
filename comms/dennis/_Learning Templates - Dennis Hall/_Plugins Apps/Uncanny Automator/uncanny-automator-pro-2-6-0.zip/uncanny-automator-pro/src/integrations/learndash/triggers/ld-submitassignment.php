<?php

namespace Uncanny_Automator_Pro;

/**
 * Class LD_SUBMITASSIGNMENT
 * @package Uncanny_Automator_Pro
 */
class LD_SUBMITASSIGNMENT {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'LD';

	private $trigger_code;
	private $trigger_meta;

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {
		$this->trigger_code = 'LD_SUBMITASSIGNMENT';
		$this->trigger_meta = 'LDLESSON';
		$this->define_trigger();
	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function define_trigger() {

		global $uncanny_automator;

		$args = [
			'post_type'      => 'sfwd-courses',
			'posts_per_page' => 999,
			'orderby'        => 'title',
			'order'          => 'ASC',
			'post_status'    => 'publish',
		];

		$course_relevant_tokens = [
			'LDCOURSE'     => __( 'Course Title', 'uncanny-automator' ),
			'LDCOURSE_ID'  => __( 'Course ID', 'uncanny-automator' ),
			'LDCOURSE_URL' => __( 'Course URL', 'uncanny-automator' ),
		];
		$lesson_relevant_tokens = [
			$this->trigger_meta          => __( 'Lesson Title', 'uncanny-automator' ),
			$this->trigger_meta . '_ID'  => __( 'Lesson ID', 'uncanny-automator' ),
			$this->trigger_meta . '_URL' => __( 'Lesson URL', 'uncanny-automator' ),
		];


		$course_options = $uncanny_automator->helpers->recipe->options->wp_query( $args, true, __( 'Any course', 'uncanny-automator' ) );

		$trigger = array(
			'author'              => $uncanny_automator->get_author_name( $this->trigger_code ),
			'support_link'        => $uncanny_automator->get_author_support_link( $this->trigger_code ),
			'integration'         => self::$integration,
			'code'                => $this->trigger_code,
			/* translators: Logged-in trigger - LearnDash */
			'sentence'            => sprintf( __( 'A user submits an assignment for {{a lesson or topic:%1$s}}', 'uncanny-automator-pro' ), $this->trigger_meta ),
			/* translators: Logged-in trigger - LearnDash */
			'select_option_name'  => __( 'A user submits an assignment for {{a lesson or topic}}', 'uncanny-automator-pro' ),
			'action'              => 'learndash_assignment_uploaded',
			'priority'            => 10,
			'accepted_args'       => 2,
			'validation_function' => array( $this, 'assignment_uploaded' ),
			'options'             => [
				$uncanny_automator->helpers->recipe->options->number_of_times(),
			],
			'options_group'       => [
				$this->trigger_meta => [
					$uncanny_automator->helpers->recipe->field->select_field_ajax(
						'LDCOURSE',
						__( 'Course', 'uncanny-automator' ),
						$course_options,
						'',
						'',
						false,
						true,
						[
							'target_field' => 'LDLESSON',
							'endpoint'     => 'select_lesson_from_course_LD_SUBMITASSIGNMENT',
						],
						$course_relevant_tokens
					),
					$uncanny_automator->helpers->recipe->field->select_field(
						$this->trigger_meta,
						__( 'Select a Lesson/Topic', 'uncanny-automator-pro' ),
						[],
						false,
						false,
						false,
						$lesson_relevant_tokens
					),
				],
			],
		);

		$uncanny_automator->register->trigger( $trigger );

		return;
	}

	/**
	 * Validation function when the trigger action is hit
	 *
	 * @param $assignment_post_id
	 * @param $assignment_meta
	 */
	public function assignment_uploaded( $assignment_post_id, $assignment_meta ) {

		if ( empty( $assignment_meta ) ) {
			return;
		}

		global $uncanny_automator;

		$args = [
			'code'    => $this->trigger_code,
			'meta'    => $this->trigger_meta,
			'post_id' => $assignment_meta['lesson_id'],
			'user_id' => $assignment_meta['user_id'],
		];

		$args = $uncanny_automator->maybe_add_trigger_entry( $args, false );
		if ( $args ) {
			foreach ( $args as $result ) {
				if ( true === $result['result'] ) {
					$uncanny_automator->insert_trigger_meta(
						[
							'user_id'        => $assignment_meta['user_id'],
							'trigger_id'     => $result['args']['trigger_id'],
							'meta_key'       => 'LDCOURSE',
							'meta_value'     => $assignment_meta['course_id'],
							'trigger_log_id' => $result['args']['get_trigger_id'],
							'run_number'     => $result['args']['run_number'],
						]
					);
					$uncanny_automator->maybe_trigger_complete( $result['args'] );
				}
			}
		}
	}
}
