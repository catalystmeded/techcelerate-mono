<?php


namespace Uncanny_Automator_Pro;


use Uncanny_Automator\Wp_Helpers;

/**
 * Class Wp_Pro_Helpers
 * @package Uncanny_Automator_Pro
 */
class Wp_Pro_Helpers extends Wp_Helpers {

	/**
	 * @var bool
	 */
	public $load_options = true;

	/**
	 * Wp_Pro_Helpers constructor.
	 */
	public function __construct() {
		// Selectively load options
		if ( property_exists( '\Uncanny_Automator\Wp_Helpers', 'load_options' ) ) {
			global $uncanny_automator;
			$this->load_options = $uncanny_automator->helpers->recipe->maybe_load_trigger_options( __CLASS__ );
		}

		add_action( 'wp_ajax_select_custom_post_by_type_post_meta', array( $this, 'select_custom_post_func' ) );
		add_action( 'wp_ajax_select_all_post_from_SELECTEDPOSTTYPE', array( $this, 'select_posts_by_post_type' ) );
	}

	/**
	 * @param Wp_Pro_Helpers $pro
	 */
	public function setPro( Wp_Pro_Helpers $pro ) {
		parent::setPro( $pro );
	}


	/**
	 * @param null $label
	 * @param string $option_code
	 * @param array $args
	 *
	 * @return mixed|void
	 */
	public function all_wp_post_types( $label = null, $option_code = 'WPPOSTTYPES', $args = [] ) {
		if ( ! $this->load_options ) {
			global $uncanny_automator;

			return $uncanny_automator->helpers->recipe->build_default_options_array( $label, $option_code );
		}

		if ( ! $label ) {
			$label = __( 'Post types', 'uncanny-automator-pro' );
		}

		$token        = key_exists( 'token', $args ) ? $args['token'] : false;
		$is_ajax      = key_exists( 'is_ajax', $args ) ? $args['is_ajax'] : false;
		$target_field = key_exists( 'target_field', $args ) ? $args['target_field'] : '';
		$end_point    = key_exists( 'endpoint', $args ) ? $args['endpoint'] : '';
		$options      = [];

		$options['-1'] = __( 'Any post type', 'uncanny-automator-pro' );

		// now get regular post types.
		$args = [
			'public'   => true,
			'_builtin' => true,
		];

		$output   = 'object';
		$operator = 'and';

		$post_types = get_post_types( $args, $output, $operator );

		if ( ! empty( $post_types ) ) {
			foreach ( $post_types as $post_type ) {
				$options[ $post_type->name ] = esc_html( $post_type->labels->singular_name );
			}
		}

		// get all custom post types
		$args = [
			'public'   => true,
			'_builtin' => false,
		];

		$output   = 'object';
		$operator = 'and';

		$custom_post_types = get_post_types( $args, $output, $operator );

		if ( ! empty( $custom_post_types ) ) {
			foreach ( $custom_post_types as $custom_post_type ) {
				$options[ $custom_post_type->name ] = esc_html( $custom_post_type->labels->singular_name );
			}
		}

		$type = 'select';

		$option = [
			'option_code'     => $option_code,
			'label'           => $label,
			'input_type'      => $type,
			'required'        => true,
			'supports_tokens' => $token,
			'is_ajax'         => $is_ajax,
			'fill_values_in'  => $target_field,
			'endpoint'        => $end_point,
			'options'         => $options,
			'relevant_tokens' => [
				$option_code          => __( 'Post title', 'uncanny-automator-pro' ),
				$option_code . '_ID'  => __( 'Post ID', 'uncanny-automator-pro' ),
				$option_code . '_URL' => __( 'Post URL', 'uncanny-automator-pro' ),
			],
		];

		return apply_filters( 'uap_option_all_wp_post_types', $option );
	}

	/**
	 * Return all the specific fields of post type in ajax call
	 */
	public function select_posts_by_post_type() {
		global $uncanny_automator;

		$uncanny_automator->utilities->ajax_auth_check( $_POST );
		$fields = [];
		if ( isset( $_POST ) && key_exists( 'value', $_POST ) && ! empty( $_POST['value'] ) ) {
			$post_type = sanitize_text_field( $_POST['value'] );

			$args       = array(
				'posts_per_page'   => 999,
				'orderby'          => 'title',
				'order'            => 'ASC',
				'post_type'        => $post_type,
				'post_status'      => 'publish',
				'suppress_filters' => true,
				'fields'           => array( 'ids', 'titles' ),
			);
			$posts_list = $uncanny_automator->helpers->recipe->options->wp_query( $args, false, __( 'Any Post', 'uncanny-automator-pro' ) );

			if ( ! empty( $posts_list ) ) {
				$fields[] = array(
					'value' => '-1',
					'text'  => sprintf( _x( 'Any %s', 'WordPress post type', 'uncanny-automator-pro' ), $post_type ),
				);
				foreach ( $posts_list as $post_id => $post_title ) {
					// Check if the post title is defined
					$post_title = ! empty( $post_title ) ? $post_title : sprintf( __( 'ID: %1$s (no title)', 'uncanny-automator-pro' ), $post_id );

					$fields[] = array(
						'value' => $post_id,
						'text'  => $post_title,
					);
				}
			} else {
				$fields[] = array(
					'value' => '-1',
					'text'  => __( 'Any post', 'uncanny-automator' ),
				);
			}
		}
		echo wp_json_encode( $fields );
		die();
	}
}