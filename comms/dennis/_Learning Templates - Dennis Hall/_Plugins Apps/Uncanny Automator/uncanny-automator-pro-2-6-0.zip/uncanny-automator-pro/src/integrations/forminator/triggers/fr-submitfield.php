<?php

namespace Uncanny_Automator_Pro;

/**
 * Class FR_SUBMITFIELD
 * @package Uncanny_Automator_Pro
 */
class FR_SUBMITFIELD {

	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'FR';

	private $trigger_code;
	private $trigger_meta;

	/**
	 * Set up Automator trigger constructor.
	 */
	public function __construct() {
		$this->trigger_code = 'FRSUBMITFIELD';
		$this->trigger_meta = 'FRFORM';
		$this->define_trigger();
	}

	/**
	 * Define and register the trigger by pushing it into the Automator object
	 */
	public function define_trigger() {

		global $uncanny_automator;

		$trigger = array(
			'author'              => $uncanny_automator->get_author_name(),
			'support_link'        => $uncanny_automator->get_author_support_link(),
			'integration'         => self::$integration,
			'code'                => $this->trigger_code,
			'sentence'            => sprintf(
			/* translators: Logged-in trigger - Forminator */
				__( 'A user submits {{a form:%1$s}} with {{a specific value:%2$s}} in {{a specific field:%3$s}}', 'uncanny-automator-pro' ),
				$this->trigger_meta,
				'SUBVALUE' . ':' . $this->trigger_meta,
				$this->trigger_code . ':' . $this->trigger_meta
			),
			/* translators: Logged-in trigger - Forminator */
			'select_option_name'  => __( 'A user submits {{a form}} with {{a specific value}} in {{a specific field}}', 'uncanny-automator-pro' ),
			'action'              => 'forminator_custom_form_after_save_entry',
			'priority'            => 10,
			'accepted_args'       => 4,
			'validation_function' => array( $this, 'fr_submit_form' ),
			'options'             => [],
			'options_group'       => [
				$this->trigger_meta => [
					$uncanny_automator->helpers->recipe->forminator->options->all_forminator_forms( null, $this->trigger_meta, [
						'token'        => false,
						'is_ajax'      => true,
						'target_field' => $this->trigger_code,
						'endpoint'     => 'select_form_fields_FRFORMS',
					] ),
					$uncanny_automator->helpers->recipe->field->select_field( $this->trigger_code, __( 'Field', 'uncanny-automator-pro' ) ),
					$uncanny_automator->helpers->recipe->field->text_field( 'SUBVALUE', __( 'Value', 'uncanny-automator-pro' ) ),
				],
			],
		);

		$uncanny_automator->register->trigger( $trigger );

		return;
	}

	/**
	 * Validation function when the trigger action is hit
	 *
	 * @param int $form_id submitted form id.
	 * @param array $response response array.
	 * @param string $args form type.
	 */
	public function fr_submit_form( $form_id, $response, $args ) {
		if ( true === $response['success'] ) {
			global $uncanny_automator;
			$recipes    = $uncanny_automator->get->recipes_from_trigger_code( $this->trigger_code );
			$form_entry = forminator_get_latest_entry_by_form_id( $form_id );
			$user_id    = get_current_user_id();
			if ( empty( $user_id ) ) {
				return;
			}

			if ( empty( $form_entry ) ) {
				return;
			}

			$conditions = $this->match_condition( $form_entry, $form_id, $recipes, $this->trigger_meta, $this->trigger_code, 'SUBVALUE' );

			if ( ! $conditions ) {
				return;
			}

			$user_id = get_current_user_id();
			if ( ! empty( $conditions ) ) {
				foreach ( $conditions['recipe_ids'] as $recipe_id ) {
					if ( ! $uncanny_automator->is_recipe_completed( $recipe_id, $user_id ) ) {
						$args = [
							'code'            => $this->trigger_code,
							'meta'            => $this->trigger_meta,
							'recipe_to_match' => $recipe_id,
							'ignore_post_id'  => true,
							'user_id'         => $user_id,
						];

						$args = $uncanny_automator->maybe_add_trigger_entry( $args, false );

						$recipe_to_match = $uncanny_automator->get_recipes_data( true, $recipe_id );
						do_action( 'automator_save_forminator_form_entry', $form_id, $recipe_to_match, $args );

						if ( $args ) {
							foreach ( $args as $result ) {
								if ( true === $result['result'] ) {
									$uncanny_automator->maybe_trigger_complete( $result['args'] );
									break;
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Match condition for form field and value.
	 *
	 * @param object $entry .
	 * @param null|array $recipes .
	 * @param null|string $trigger_meta .
	 * @param null|string $trigger_code .
	 * @param null|string $trigger_second_code .
	 *
	 * @return array|bool
	 */
	public function match_condition( $entry, $form_id, $recipes = null, $trigger_meta = null, $trigger_code = null, $trigger_second_code = null ) {
		if ( null === $recipes ) {
			return false;
		}

		if ( empty( $entry ) ) {
			return false;
		}

		$matches        = [];
		$recipe_ids     = [];
		$entry_to_match = $form_id;
		foreach ( $recipes as $recipe ) {
			foreach ( $recipe['triggers'] as $trigger ) {
				if ( key_exists( $trigger_meta, $trigger['meta'] ) && $trigger['meta'][ $trigger_meta ] === $entry_to_match ) {
					$matches[ $recipe['ID'] ]    = [
						'field' => $trigger['meta'][ $trigger_code ],
						'value' => $trigger['meta'][ $trigger_second_code ],
					];
					$recipe_ids[ $recipe['ID'] ] = $recipe['ID'];
					break;
				}
			}
		}

		if ( ! empty( $matches ) ) {
			foreach ( $matches as $recipe_id => $match ) {
				if ( $entry->get_meta( $match['field'] ) !== $match['value'] ) {
					unset( $recipe_ids[ $recipe_id ] );
				}
			}
		}

		if ( ! empty( $recipe_ids ) ) {
			return [ 'recipe_ids' => $recipe_ids, 'result' => true ];
		}

		return false;
	}
}
