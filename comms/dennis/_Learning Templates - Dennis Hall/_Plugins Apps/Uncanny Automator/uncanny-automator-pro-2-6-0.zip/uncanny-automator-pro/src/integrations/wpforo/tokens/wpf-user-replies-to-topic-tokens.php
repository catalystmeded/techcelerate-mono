<?php

namespace Uncanny_Automator_Pro;

/**
 * Class WPF_USER_REPLIES_TO_TOPIC_TOKENS
 * @package Uncanny_Automator_Pro
 */
class WPF_USER_REPLIES_TO_TOPIC_TOKENS {


	/**
	 * Integration code
	 * @var string
	 */
	public static $integration = 'WPFORO';

	public function __construct() {
		add_filter( 'automator_maybe_parse_token', [ $this, 'user_replies_to_topic' ], 20, 6 );
	}

	/**
	 * Only load this integration and its triggers and actions if the related plugin is active
	 *
	 * @param $status
	 * @param $code
	 *
	 * @return bool
	 */
	public function plugin_active( $status, $code ) {

		if ( self::$integration === $code ) {

			$status = true;
		}

		return $status;
	}

	/**
	 * @param $value
	 * @param $pieces
	 * @param $recipe_id
	 * @param $trigger_data
	 *
	 * @return mixed
	 */
	public function user_replies_to_topic( $value, $pieces, $recipe_id, $trigger_data, $user_id, $replace_args ) {

		$tokens = [
			'WPFORO_FORUM',
			'WPFORO_FORUM_ID',
			'WPFORO_FORUM_URL',
			'WPFORO_TOPIC',
			'WPFORO_TOPIC_ID',
			'WPFORO_TOPIC_URL'
		];


		if ( $pieces && isset( $pieces[2] ) ) {
			$meta_field = $pieces[2];

			if ( ! empty( $meta_field ) && in_array( $meta_field, $tokens ) ) {
				if ( $trigger_data ) {
					foreach ( $trigger_data as $trigger ) {
						$trigger_id = $trigger['ID'];

						Utilities::log( [
							'$trigger' => $trigger,
						], 'testing', true, 'user_replies_to_topic' );

						switch ( $meta_field ) {
							case 'WPFORO_FORUM':
								$value = $trigger['meta']['FOROFORUM_readable'];
								break;
							case 'WPFORO_FORUM_ID':
								$value = $trigger['meta']['FOROFORUM'];
								break;
							case 'WPFORO_FORUM_URL':
								$forum = WPF()->forum->get_forum( $trigger['meta']['FOROFORUM'] );
								$value = wpforo_home_url( utf8_uri_encode( $forum['slug'] ) );
								break;
							case 'WPFORO_TOPIC':
								$value = $trigger['meta']['FOROTOPIC_readable'];
								break;
							case 'WPFORO_TOPIC_ID':
								$value = $trigger['meta']['FOROTOPIC'];
								break;
							case 'WPFORO_TOPIC_URL':

								$forum_slug = WPF()->topic->get_forumslug( $trigger['meta']['FOROFORUM'] );
								$topic      = WPF()->topic->get_topic( $trigger['meta']['FOROTOPIC'] );

								if ( is_array( $topic ) && ! empty( $topic ) ) {
									if ( wpfval( $topic, 'slug' ) ) {
										$value = wpforo_home_url( $forum_slug . '/' . $topic['slug'] );
									}
								}
								break;
						}
					}
				}
			}
		}

		return $value;
	}

	/**
	 * @param $meta_key
	 * @param $trigger_id
	 *
	 * @return mixed|string
	 */
	public function get_form_data_from_trigger_meta( $meta_key, $trigger_id ) {
		global $wpdb;
		if ( empty( $meta_key ) || empty( $trigger_id ) ) {
			return '';
		}

		$meta_value = $wpdb->get_var( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->prefix}uap_trigger_log_meta WHERE meta_key = %s AND automator_trigger_id = %d ORDER BY ID DESC LIMIT 0,1", $meta_key, $trigger_id ) );

		if ( ! empty( $meta_value ) ) {
			return maybe_unserialize( $meta_value );
		}

		return '';
	}
}
