=== Uncanny Redemption Codes ===
Contributors: uncannyowl
Tags: Automator, automation, LearnDash, eLearning, LMS
Requires at least: 5.8
Tested up to: 6.8.2
Requires PHP: 7.4
Stable tag: 5.0.0
License: This plugin is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or any later version. Uncanny Redemption Codes is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details. You should have received a copy of the GNU General Public License along with Uncanny Redemption Codes. If not, see {URI to Plugin License}.
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Generate, track and sell codes that can be redeemed for access, membership and more in 50+ plugins and apps

== Description ==
**Important: This plugin requires PHP 7.4 or higher.**
